/**
 * 
 */
/**
 * 
 */
module tamrin1 {
	requires java.logging;
	requires java.sql;
	requires com.fasterxml.jackson.databind;
	exports tamrin1.session7.jsons to com.fasterxml.jackson.databind;	
}