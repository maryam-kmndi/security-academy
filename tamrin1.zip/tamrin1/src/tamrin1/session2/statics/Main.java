package tamrin1.session2.statics;

public class Main {

	public static void main(String[] args) {
		int a = MathUtility.unsignedNumber(62000);
		int b = MathUtility.unsignedNumber(-62000);
		
		System.out.println(a);
		System.out.println(b);
	}

}
