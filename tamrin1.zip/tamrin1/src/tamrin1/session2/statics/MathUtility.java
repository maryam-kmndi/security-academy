package tamrin1.session2.statics;

public class MathUtility {
	public static int unsignedNumber(int i) {
		if (i > 0) {
			return i;
		} else {
			return -i;
		}
	}

}
