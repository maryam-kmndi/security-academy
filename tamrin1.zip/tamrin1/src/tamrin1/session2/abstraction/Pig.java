package tamrin1.session2.abstraction;

public class Pig extends Animal {

	@Override
	public void animalSound() {
		System.out.println("The pig says: wee wee");
	}

}
