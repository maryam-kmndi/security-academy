package tamrin1.session4.exceptions;

public class InvalidAgeException extends Exception{
	private static final long serialVersionUID = 1L;

	public InvalidAgeException(String msg) {
		super(msg);
	}

}
