package tamrin1.session7.annotation;

public class Main {
	
	public static void main(String[] args) {
		int add = Calculator.add(5, 12);
		int multiple = Calculator.multi(5, 12);
		
		System.out.println(add);
		System.out.println(multiple);
	}

}
